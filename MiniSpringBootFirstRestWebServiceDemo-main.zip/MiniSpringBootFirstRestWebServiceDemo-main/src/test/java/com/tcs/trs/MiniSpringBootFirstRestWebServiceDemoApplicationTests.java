package com.tcs.trs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniSpringBootFirstRestWebServiceDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
