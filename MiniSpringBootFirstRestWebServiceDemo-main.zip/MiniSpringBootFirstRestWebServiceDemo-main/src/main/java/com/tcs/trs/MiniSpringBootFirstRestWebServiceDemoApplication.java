package com.tcs.trs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiniSpringBootFirstRestWebServiceDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiniSpringBootFirstRestWebServiceDemoApplication.class, args);
	}

}
